import csv
import json
from collections import Counter
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

from render_report import pdf_from_docx, write_docx


ROOT = Path(__file__).resolve().parents[1]
EVAL = ROOT / '.findit-eval-work'
OUTPUT = ROOT / 'output' / 'FindIT NLP'
STEM = 'Campus Lost and Found System (FindIT)'
SUPPORT = 'FindIT NLP Evaluation Materials.zip'
RESULTS = json.loads((EVAL / 'results.json').read_text(encoding='utf-8'))
with (EVAL / 'corpus.csv').open(encoding='utf-8-sig', newline='') as source:
    CORPUS = {row['id']: row for row in csv.DictReader(source)}


def p(text):
    return ('Normal', text)


def h(text):
    return ('Heading 1', text)


def sub(text):
    return ('Heading 2', text)


def table(widths, headings, rows):
    assert sum(widths) == 468
    return ('table', widths, [headings, *rows])


def reference(text):
    return ('Reference', text)


def fmt_words(words):
    return ', '.join(words) if words else 'None'


NOTES = [
    'Two edits connect cellfone to cellphone and the phone item category.',
    'Filters Filipino function words and corrects Samsng to Samsung.',
    'Splits letters and digits, retaining model 13 and the Apple and phone entities.',
    'Tags katad as leather. The suffix rule turns labas into laba and may change meaning.',
    'Folds the apostrophe and resolves the campus place. Only the location signal uses this field.',
    'Keeps the shade words and maps the phrase to the canonical blue color.',
    'Recognizes bottle before removing the Filipino connector ng from lexical features.',
    'Reduces keys to key and retains identifying words such as felt, owl and charm.',
    'Corrects Airpds; interprets CBAA Building as a location and leaves it out of text features.',
    'Falsely treats polka as the campus place polca and drops an identifying word.',
    'Drops not; USB adds a drive entity even though it describes a mouse.',
    'The three-letter fna remains as written and produces no item entity for the name.',
]


def before_after_rows():
    rows = []
    for example, note in zip(RESULTS['preprocessing'], NOTES, strict=True):
        raw = f"{example['id']} {example['field']}\n{example['raw']}"
        stages = ('Tokens: ' + fmt_words(example['tokens_after_folding_and_stemming'])
                  + '\nRetained: ' + fmt_words(example['retained_lexical_tokens']))
        rows.append((raw, stages, note))
    return rows


def percent(value):
    return f'{value * 100:.1f}%'


def fmt_metric(metric):
    low, high = metric['ci95']
    return f"{metric['hits']}/{metric['total']}\n{percent(metric['rate'])}\n{low * 100:.1f}–{high * 100:.1f}%"


VARIANTS = [
    ('lexical', 'Lexical baseline'),
    ('hybrid_default', 'FindIT default'),
    ('hybrid_no_typos', 'FindIT without typo correction'),
    ('hybrid_tuned', 'FindIT with tuned score floor'),
]
KEYS = ('matched_top1', 'matched_top3', 'no_match_rejection', 'all_correct')


def metric_rows():
    return [(label, *(fmt_metric(RESULTS['splits']['test'][key]['metrics'][metric]) for metric in KEYS))
            for key, label in VARIANTS]


def format_hit(variant, query):
    case = next(row for row in RESULTS['splits']['test'][variant]['cases'] if row['id'] == query)
    if case['top']:
        hit = case['top'][0]
        return f"{hit['id']} ({hit['score']})"
    return 'No suggestion'


CASE_NOTES = {
    'Q19': ('Airpds and a peach silicone cover', 'Typo correction raised F13 from 63 to 78.'),
    'Q23': ('No triangle patch, rectangle patch on the strap', 'The default ranked the negated triangle detail first.'),
    'Q24': ('Black bag with an oval patch', 'Shared nylon, color, place and date outweighed the distinctive patch.'),
    'Q25': ('Payong with polka dots and a bent rib', 'Correct by default. The higher floor removed the result.'),
    'Q28': ('Not the USB mouse with a red scroll wheel', 'The negated mouse outranked the intended wireless mouse.'),
    'Q29': ('Wired optical mouze with a red scroll wheel', 'Typo correction raised F20 from 79 to 93.'),
    'Q33': ('Blue ID card on a plain strap, lost weeks later', 'F22 was found 17 days before the reported loss.'),
    'Q35': ('Handheld fna with a heart charm', 'The short typo survived. The tuned floor rejected F24.'),
}


def case_rows():
    return [(f'{key}\n{description}', CORPUS[key]['expected'] or 'None',
             format_hit('hybrid_default', key), format_hit('hybrid_tuned', key), note)
            for key, (description, note) in CASE_NOTES.items()]


SAMPLE_IDS = ('F01', 'Q01', 'Q04', 'Q07', 'Q08', 'Q10', 'F13', 'Q19', 'Q20', 'Q21', 'Q23',
              'Q25', 'F19', 'F20', 'Q28', 'Q31', 'Q33', 'Q35')


def sample_rows():
    return [(f"{key} {CORPUS[key]['type']}", CORPUS[key]['name'], CORPUS[key]['description'])
            for key in SAMPLE_IDS]


before_after = before_after_rows()
threshold_pairs = [f'{key} → {percent(value)}' for key, value in
                   RESULTS['development_balanced_accuracy_by_threshold'].items()]
threshold_caption = '\n'.join('    |    '.join(threshold_pairs[start:start + 4]) for start in (0, 4))
languages = Counter(CORPUS[key]['language'] for key in CORPUS if CORPUS[key]['type'] == 'lost')

pages = [
    [
        ('Cover Institution', 'De La Salle University Dasmariñas'),
        ('Cover Department', 'College of Information and Computer Studies\nComputer Science Department'),
        ('Title', 'FindIT Campus Lost and Found System'),
        ('Cover Subtitle', 'Natural Language Processing Final Project\nLecture Submission'),
        ('Cover Label', 'Group Members'),
        ('Cover Blank', '\u00a0'),
        ('Cover Date', 'December 5, 2026'),
    ],
    [
        h('Part 1 Introduction Scope and Hypothesis'),
        p('FindIT is a campus lost-and-found system for the Student Welfare and Formation Office (SWAFO) at De La Salle University Dasmariñas. It replaces a paper logbook with a searchable inventory and a way to report, claim and recover items. The system includes a ranking tool that helps staff compare a lost report with found records. A staff member verifies ownership through the claim workflow before an item is released.'),
        sub('Problem Statement'),
        p('The person who lost an item and the person who found it often describe it differently. A lost report may say “Airpds” or use Filipino and English together, while the found entry says “wireless headset.” Exact string matching may miss the connection. A broad match based on words like “black bag” can also put an unrelated item first. The research problem is to rank the correct found item despite wording differences and withhold a suggestion when the inventory contains no true match.'),
        sub('Research Question and Hypothesis'),
        p('Among reports with a true counterpart, does FindIT’s TF-IDF ranker with canonical entities, typo correction and structured signals place the correct found item first more often than exact-token lexical ranking? The hypothesis predicts higher held-out matched Top-1 for the default FindIT matcher. The benchmark also measures the effect of disabling typo correction and tests whether a development-selected score floor increases rejection of unmatched queries.'),
        sub('Scope and Target Metrics'),
        p('The study covers text and structured report fields for lost-to-found retrieval. The primary metric is matched Top-1, the share of matchable queries with the correct candidate ranked first. Supporting metrics are matched Top-3, correct rejection of queries with no true candidate and overall correct decisions. The synthetic cases test text processing and ranking, while ownership verification remains a separate step in the application.'),
        sub('Course Outcomes and Project Components'),
        p('Feature extraction is demonstrated by tokenization, entity lookup and TF-IDF. Feature engineering is demonstrated by alias normalization, field weights and the use of date, location and category. Evaluation is demonstrated by a lexical baseline, a typo-correction ablation, grouped development and test partitions, threshold tuning and analysis of errors. The work treats ranking as an information retrieval task and measures it at the point where SWAFO reviews suggestions.'),
    ],
    [
        h('Part 2 Data Acquisition and Ethics'),
        sub('Text Source and Collection'),
        p(f'The study corpus contains {len(CORPUS)} distinct fictional reports authored for this project, including 36 lost queries and 24 found records. The text and metadata follow FindIT’s report form, campus place list and item category list [1]. Each row contains an item name, short description, category, color, location and event date. Optional fields include brand, identifying detail and free-text location. The corpus adds a synthetic ID, scenario group, language, challenge type and expected found ID. An empty expected field denotes a lost report with no corresponding found record.'),
        p(f'Each of 12 scenario groups describes two found items, two lost reports for those items and one unmatched lost report. Same-family candidates deliberately share attributes such as a color, place and date. Six groups form the development partition and six form the held-out partition. Each partition contains 30 source texts, including 18 queries and 12 candidates. Appendix A reproduces {len(SAMPLE_IDS)} report texts. The accompanying corpus.csv contains the complete 60-row collection and labels.'),
        sub('Language Characteristics and Challenges'),
        p(f'Of the 36 lost reports, {languages["EN"]} are labeled English and {languages["Mixed"]} mix Filipino and English. The descriptions use noun phrases, short sentences, color words such as itim, asul and dilaw, and reporting expressions such as naiwan or nawala. Model names and abbreviations include iPhone13, USB, CBAA and MAH. “Lalagyan ng tubig” and “water bottle” illustrate different names for the same item type. “Mouze,” “Samsng” and “fna” test spelling variation. “Mouse” and MAH illustrate ambiguity, while the USB-mouse example tests the effect of negation on meaning.'),
        sub('Privacy and Appropriate Use'),
        p('The corpus uses fictional incidents, dates and identifying details. Campus place names follow the application’s location list. It contains no real student names, contact details, ID numbers, photos, messages, claim proofs or database records. The system’s public description and staff-only identifying fields serve different purposes [1]. Any later field study should use SWAFO-authorized records, remove personal and ownership-proof details before analysis, restrict access and report aggregate results.'),
        sub('Relevance to FindIT'),
        p('The paired descriptions represent the same item in different words, which allows direct checking of retrieval. Same-category distractors test whether the system attends to identifying details. Unmatched reports measure the risk of giving staff a plausible but incorrect candidate.'),
    ],
    [
        h('Part 3 Data Preprocessing and Feature Engineering'),
        p('The application compares an open report against unclaimed reports of the opposite type. It builds a representation from the item name, color, description, brand and identifying details. Location, category and date contribute separate signals. The stages below follow the repository implementation [1].'),
        table((125, 343), ('Stage', 'FindIT implementation'), [
            ('Cleaning and normalization', 'Converts text to Unicode NFC, then folds token accents, removes apostrophes and lowercases. The token pattern skips punctuation and spaces, including repeated spaces.'),
            ('Tokenization', 'Splits word spans into letter and digit runs. iPhone13 becomes iphone and 13. Offsets preserve the location of each original span for entity detection.'),
            ('Light stemming', 'Drops final s for words longer than three characters unless they end in ss. Keys becomes key. The same rule processes both user text and dictionary entries.'),
            ('Entity recognition', 'Uses a campus and item dictionary to find the longest matching phrases. It emits ITEM, BRAND, COLOR, MATERIAL and LOCATION. A brand can imply an item type. Alias examples include CBAA and gregoria-de-jesus-hall.'),
            ('Spelling correction', 'Uses Levenshtein edit distance [4] for selected entity words. The candidate must be a unique nearest dictionary spelling with the same initial. Tokens of 5–7 letters allow one edit; tokens of 8 or more allow two. Known words on a protected list are preserved.'),
            ('Stop-word filtering', 'Removes common English and Filipino words, tokens shorter than two characters and recognized location spans from the text vector. Phrase recognition runs first, so ng can contribute to a recognized phrase before filtering.'),
        ]),
        p('Removing words such as po and ang reduces uninformative overlap. Dropping no, not and without can invert identifying details because the ranker treats the remaining words as positive evidence. A short code or size such as “M” can also disappear under the single-character rule.'),
    ],
    [
        h('Part 3 Feature Encoding and Scoring'),
        p('The name contributes a count of two per retained token, while each other text field contributes one. Canonical entity features contribute twice their field weight. For example, Airpds can contribute airpod, brand:Apple and item:earbuds. Location spans are excluded from the lexical counts and enter the separate place comparison.'),
        p('FindIT applies term frequency–inverse document frequency (TF-IDF) [3]. For term count c and document frequency df in an index of N reports, the unscaled weight is (1 + ln(c)) × [ln((1 + N) / (1 + df)) + 1]. Each vector is then scaled to unit L2 length. The dot product of two unit vectors gives cosine similarity. Frequent, generic words carry less discriminative weight than rare terms such as a distinctive sticker.'),
        table((115, 353), ('Signal', 'Encoding and weight'), [
            ('Text (60%)', 'Cosine similarity of L2-normalized TF-IDF feature vectors.'),
            ('Place (15%)', '1 for a shared location, 0.5 for a shared campus and 0 otherwise. For an unspecified structured place, the system can infer a place from report text.'),
            ('Category (15%)', '1 for an equal category and 0 otherwise.'),
            ('Date (10%)', '1 if the item was found from one day before through seven days after the reported loss. The weight then falls linearly to zero at 60 days. Missing dates and findings more than one day before loss score zero.'),
        ]),
        p('The weighted sum is multiplied by 100 and rounded. The app sorts by score and uses text similarity to break score ties. It shows up to ten results with a text score of at least 0.10 and a total score of at least 40. These are uncalibrated ranking scores for staff review.'),
        sub('Stemming and Lemmatization'),
        table((146, 146, 176), ('Input in context', 'FindIT stem', 'Reference lemma'), [
            ('keys (noun plural)', 'key', 'key'), ('boxes (noun plural)', 'boxe', 'box'),
            ('running (verb)', 'running', 'run'), ('was (verb)', 'was', 'be'),
        ]),
        p('FindIT uses the suffix rule for production matching. The reference lemmas illustrate the word forms a grammatical lemmatizer would seek. The suffix rule also gives an incorrect form for the Filipino word labas in the examples below.'),
    ],
    [
        h('Part 3 Before and After Processing'),
        p('The tables show measured output from the FindIT tokenizer and analyzer. “Tokens” are lowercased, folded and lightly stemmed. “Retained” shows the lexical terms after entity correction and filtering. Canonical features are explained in the last column. A location-only field has no lexical text contribution.'),
        table((142, 166, 160), ('Original report text', 'Tokenization and filtering', 'Observed change'), before_after[:6]),
    ],
    [
        h('Part 3 Before and After Processing Continued'),
        table((142, 166, 160), ('Original report text', 'Tokenization and filtering', 'Observed change'), before_after[6:]),
        sub('Effect on Matching'),
        p('Entity normalization helps connect variant spellings such as Airpds and AirPods. It can also erase useful evidence. The umbrella report loses polka because that word is corrected to a campus location, and the mouse report retains the attributes it explicitly denies. Part 4 tracks how those preprocessing choices affect actual rankings.'),
    ],
    [
        h('Part 3 Source Code Demonstration'),
        p('The following excerpt calls the same standard-library NLP functions used by FindIT. Run it from the project’s backend folder. The evaluation script in the accompanying materials executes the same operations on twelve fields and records token sequences, entity spans and weighted feature counts.'),
        ('Report Code', '''from algorithms import extract_entities, report_terms
from algorithms.textutils import STOPWORDS, _clean, stem, tokenize

raw = '  Naiwan ang ASUL na lalagyan ng tubig!!!  '
tokens = [token.word for token in tokenize(_clean(raw))]
kept = [word for word in tokens if word not in STOPWORDS]

print('Input:', raw)
print('Tokens:', tokens)
print('After common stop words:', kept)
print('Entities:', extract_entities(raw))
print('Weighted features:', dict(report_terms({'description': raw})))

lemmas = {'keys': 'key', 'boxes': 'box', 'running': 'run', 'was': 'be'}
for word, reference_lemma in lemmas.items():
    print(word, stem(word), reference_lemma)'''),
        sub('Expected Behavior'),
        p('The tokenizer removes surrounding spaces and exclamation points, and lowercases ASUL to asul. The stop-word list removes naiwan, ang, na and ng. Entity recognition uses the full phrase lalagyan ng tubig to return bottle. The features include color:blue from asul. The final four lines compare actual FindIT stems with reference lemmas.'),
        p('The packaged evaluate.py expands this demonstration to include the lexical baseline, exact production Matcher calls, two matching configurations and the threshold comparison. Appendix B describes how to reproduce the outputs.'),
    ],
    [
        h('Part 4 Model Development and Evaluation Design'),
        p('The experiment compares four ranking configurations on a common inventory. Each of 18 queries in a partition is evaluated against its 12 found records. The scenario groups keep all descriptions of a particular item together, while reports from other groups provide additional distractors. All candidates are open in the benchmark. The original app uses Boyer–Moore for its browse search and the hybrid ranker for staff matching [1].'),
        table((147, 321), ('Configuration', 'Development and rationale'), [
            ('Lexical baseline', 'Normalizes to Unicode NFC and tokenizes lowercased text into whole words. Uses FindIT’s Boyer–Moore primitive [2] for exact token membership and ranks by Jaccard set overlap. It returns candidates sharing a token. This report-ranking baseline reuses the public search primitive.'),
            ('Default FindIT', 'Runs the complete production ranker with typo correction, canonical terms, fixed feature weights and a score floor of 40.'),
            ('FindIT without typo correction', 'Keeps the same ranker, weights and floors, with fix_typos=False. This isolates the contribution of dictionary typo handling.'),
            ('FindIT with tuned score floor', 'Runs the same hybrid scores with a higher minimum total score selected on development. The text floor stays at 0.10.'),
        ]),
        p('Each query’s hybrid index estimates IDF from that query and the 12 unlabeled candidate records in its own partition. The production app indexes all reports available at request time. The experiment uses unsupervised IDF estimation with fixed scoring rules. The 50/50 grouped split keeps six challenge groups available for threshold selection and six for an independent held-out check. Both partitions contain 12 matchable and six unmatched queries by construction.'),
        sub('Threshold Selection'),
        p('Development balanced accuracy is the mean of matched Top-1 and correct no-match rejection. The tested score floors and development scores were:'),
        p(threshold_caption),
        p('The development set selected a floor of 75, which was then fixed for the test set. These are offline experiments and use the production scoring code without changing the system configuration.'),
    ],
    [
        h('Part 4 Held Out Results'),
        p('Matched Top-1 looks for the correct counterpart in first place. Matched Top-3 counts any appearance among the first three returned results. Correct rejection requires an empty result for an unmatched query. Overall correctness counts either a correct first choice or a correct rejection, as appropriate. Each cell gives the count, percentage and 95% Wilson score interval [5].'),
        table((132, 84, 84, 84, 84), ('Configuration', 'Matched Top-1', 'Matched Top-3', 'Reject no match', 'Overall correct'), metric_rows()),
        sub('Interpretation'),
        p('FindIT and the lexical baseline both ranked 10 of 12 true matches first, leaving the primary hypothesis unsupported on this benchmark. Both found all 12 within the first three positions. The default hybrid suggested a candidate for all six unmatched queries. Disabling typo correction changed individual scores and left aggregate results unchanged.'),
        p('The tuned floor correctly rejected four of six unmatched queries. It also removed true candidates, bringing matched Top-3 down from 12/12 to 8/12. Overall correctness rose from 10/18 to 12/18 within the hybrid family, compared with 11/18 for the lexical baseline. SWAFO’s tolerance for reviewing weak suggestions versus overlooking real matches determines which trade-off is acceptable.'),
        sub('Uncertainty and Language Bias'),
        p('The default hybrid ranked 5/7 English and 5/5 mixed-language matchable queries correctly. These small slices combine language with different items and challenge types, and found descriptions in the corpus are in English. The sample sizes and shared scenarios make the intervals descriptive of this authored benchmark. Campus-wide estimates and language-group comparisons require a larger representative sample.'),
    ],
    [
        h('Part 4 Example Decisions and Errors'),
        p('The table gives actual top results on held-out queries. Parentheses show the weighted FindIT score. “None” under Expected denotes an unmatched report. The corpus contains the original text for every row.'),
        table((126, 64, 69, 69, 140), ('Query and identifying text', 'Expected', 'Default', 'Tuned', 'Observed behavior'), case_rows()),
        p('In Q28, the wrong candidate achieves a 96 because it shares the terms USB, red and scroll wheel in addition to matching place, category and date. The high-ranking error survives threshold tuning. In Q33, the date contributes zero but the other signals still produce a score of 80. These errors show why staff need to read the original report before treating a suggestion as a possible match.'),
    ],
    [
        h('Part 4 Limitations and Real World Use'),
        sub('Handling Unfamiliar Language and Ambiguity'),
        p('Dictionary aliases and bounded typo correction handle spelling differences such as Airpds and mouze. Unfamiliar terms, very short misspellings and ambiguous aliases can miss an entity or create a wrong one. Q25 demonstrates a false correction, and Q35 shows the five-letter lower bound for fuzzy lookup. The bag-of-words vector ignores word order. English and Filipino negation, similar items with common colors, and reports with unclear locations can therefore mislead it.'),
        sub('Possible Improvements'),
        p('First, detect the scope of not, no, without and hindi, then keep negated attributes apart from positive matching features. Second, constrain fuzzy location correction to fields or phrases with credible location context and expand the glossary with SWAFO-reviewed Filipino spellings and shorthand. Third, show contradictions such as a found date well before the loss or a different identifying mark beside the score so staff can resolve them. Any stricter date rule should be tested against plausible clerical date errors.'),
        p('A follow-up experiment could compare a character n-gram ranker for short misspellings and a phrase-aware or negation-aware variant for Q28-like cases. A larger authorized, de-identified corpus should represent varied campus sites, item types, reporting habits and English, Filipino and mixed-language reports. Keep scenario groups together in development and evaluation, report error slices, and measure the trade-off between staff review volume and missed real matches.'),
        sub('Benefits and Research Contribution'),
        p('Students and employees can report losses in everyday language. SWAFO staff can use a shortlist to review possible matches faster and then check claimant evidence. The research contribution of this project is the evaluation of a campus-specific lexicon and structured signals against a transparent lexical baseline. The test cases reveal where campus knowledge helps and where dictionary corrections, missing negation or overly strong metadata can hurt a decision.'),
        p('The approach may also fit a school library, residence hall or equipment checkout office with its own place and item vocabulary. Each setting would require representative data and a review procedure appropriate to its inventory and users.'),
    ],
    [
        h('Appendix A Sample Report Texts'),
        p(f'These {len(SAMPLE_IDS)} samples come from the development and test partitions in corpus.csv. The complete collection preserves the separate fields, scenario groups and match labels for all 60 records.'),
        table((65, 103, 300), ('Record', 'Item name', 'Description'), sample_rows()),
    ],
    [
        h('Appendix B Reproduction and References'),
        sub('Reproduce the Evaluation'),
        p(f'Extract {SUPPORT} into any folder and run the command below using Python 3. The package includes corpus.csv, evaluate.py, results.json, the original FindIT algorithm files and the campus location list they read. The script uses the Python standard library and produces rankings, preprocessing examples, threshold scores and intervals offline.'),
        ('Report Code', 'python evaluate.py --repo . --output rerun.json'),
        sub('References'),
        reference('[1] FindIT Campus Lost and Found System. Project source code supplied for this study. Report form: templates/report-form.html. Campus list: static/js/data/locations.js. Category list: static/js/item-store.js. Campus workflow: templates/about.html. Admin ranking and public search: backend/app.py. Text pipeline: backend/algorithms/textutils.py, ner.py, tfidf.py, levenshtein_distance.py and boyer_moore.py.'),
        reference('[2] Boyer, R. S., and Moore, J. S. (1977). A fast string searching algorithm. Communications of the ACM, 20(10), 762–772. https://doi.org/10.1145/359842.359859'),
        reference('[3] Robertson, S. (2004). Understanding inverse document frequency: On theoretical arguments for IDF. Journal of Documentation, 60(5), 503–520. https://doi.org/10.1108/00220410410560582'),
        reference('[4] Levenshtein, V. I. (1965). Binary codes capable of correcting deletions, insertions, and reversals. Doklady Akademii Nauk SSSR, 163(4), 845–848. https://www.mathnet.ru/eng/dan31411'),
        reference('[5] Wilson, E. B. (1927). Probable inference, the law of succession, and statistical inference. Journal of the American Statistical Association, 22(158), 209–212. https://doi.org/10.2307/2276774'),
    ],
]


def main():
    OUTPUT.mkdir(parents=True, exist_ok=True)
    docx = OUTPUT / (STEM + '.docx')
    pdf = OUTPUT / (STEM + '.pdf')
    write_docx(pages, docx)
    pdf_from_docx(docx, pdf)
    with ZipFile(OUTPUT / SUPPORT, 'w', compression=ZIP_DEFLATED) as archive:
        for name in ('corpus.csv', 'evaluate.py', 'results.json'):
            archive.write(EVAL / name, name)
        for path in sorted((ROOT / 'backend' / 'algorithms').glob('*.py')):
            archive.write(path, path.relative_to(ROOT).as_posix())
        locations = Path('static/js/data/locations.js')
        archive.write(ROOT / locations, locations.as_posix())


if __name__ == '__main__':
    main()
