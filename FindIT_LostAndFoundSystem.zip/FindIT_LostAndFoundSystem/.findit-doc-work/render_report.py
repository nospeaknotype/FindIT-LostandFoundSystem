from pathlib import Path
import re
from xml.sax.saxutils import escape

from docx import Document
from docx.enum.style import WD_STYLE_TYPE
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor
from docx.table import Table as WordTable
from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_LEFT
from reportlab.lib.styles import ParagraphStyle
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfgen import canvas
from reportlab.platypus import Paragraph, Table, TableStyle


FONT = 'Times New Roman'
TITLE = 'FindIT Campus Lost and Found System'
WIDTH, HEIGHT = 612, 792
MARGIN = 72
CONTENT = WIDTH - 2 * MARGIN
SHADE = 'EDEDED'
BORDER = 'D9D9D9'

# size, exact leading, space before, space after, bold, alignment
STYLES = {
    'Normal': (12, 15, 0, 7, False, 'left'),
    'Title': (14, 18, 0, 8, True, 'center'),
    'Cover Institution': (12, 16, 104, 4, False, 'center'),
    'Cover Department': (12, 16, 0, 55, False, 'center'),
    'Cover Subtitle': (12, 16, 0, 42, False, 'center'),
    'Cover Label': (12, 16, 0, 12, True, 'center'),
    'Cover Blank': (12, 16, 0, 67, False, 'center'),
    'Cover Date': (12, 16, 0, 0, False, 'center'),
    'Heading 1': (14, 18, 0, 11, True, 'left'),
    'Heading 2': (14, 18, 6, 5, True, 'left'),
    'Table Text': (12, 14, 0, 0, False, 'left'),
    'Table Heading': (12, 14, 0, 0, True, 'left'),
    'Report Code': (12, 14, 0, 0, False, 'left'),
    'Reference': (12, 15, 0, 9, False, 'left'),
}


def styled_document():
    doc = Document()
    properties = doc.core_properties
    properties.title = TITLE
    properties.subject = 'Natural Language Processing Final Project'
    properties.author = ''
    properties.last_modified_by = ''
    properties.comments = ''
    section = doc.sections[0]
    section.page_width, section.page_height = Inches(8.5), Inches(11)
    section.top_margin = section.bottom_margin = section.left_margin = section.right_margin = Inches(1)
    section.footer_distance = Inches(0.48)
    section.different_first_page_header_footer = True
    for key, (size, leading, before, after, bold, alignment) in STYLES.items():
        style = doc.styles[key] if key in doc.styles else doc.styles.add_style(key, WD_STYLE_TYPE.PARAGRAPH)
        style.font.name = FONT
        style.font.size = Pt(size)
        style.font.bold = bold
        style.font.italic = False
        style.font.color.rgb = RGBColor(0, 0, 0)
        fonts = style._element.get_or_add_rPr().rFonts
        fonts.attrib.clear()
        for key_name in ('ascii', 'hAnsi', 'eastAsia', 'cs'):
            fonts.set(qn(f'w:{key_name}'), FONT)
        p = style.paragraph_format
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER if alignment == 'center' else WD_ALIGN_PARAGRAPH.LEFT
        p.line_spacing = Pt(leading)
        p.space_before, p.space_after = Pt(before), Pt(after)
        p.widow_control = True
        p.keep_with_next = key.startswith('Heading')
        p.keep_together = key.startswith('Heading')
    footer = section.footer.paragraphs[0]
    footer.alignment = WD_ALIGN_PARAGRAPH.CENTER
    footer.style = 'Normal'
    footer.paragraph_format.space_after = Pt(0)
    field = OxmlElement('w:fldSimple')
    field.set(qn('w:instr'), 'PAGE')
    field_run = OxmlElement('w:r')
    field_text = OxmlElement('w:t')
    field_text.text = '2'
    field_run.append(field_text)
    field.append(field_run)
    footer._p.append(field)
    return doc


def word_el(name, **attrs):
    element = OxmlElement(f'w:{name}')
    for key, value in attrs.items():
        element.set(qn(f'w:{key}'), str(value))
    return element


def write_docx(pages, target):
    doc = styled_document()
    for page_index, page in enumerate(pages):
        for index, block in enumerate(page):
            if block[0] == 'table':
                _, widths, rows = block
                table = doc.add_table(rows=len(rows), cols=len(widths))
                table.alignment = WD_TABLE_ALIGNMENT.CENTER
                table.autofit = False
                properties = table._tbl.tblPr
                table_width = properties.find(qn('w:tblW'))
                table_width.set(qn('w:type'), 'dxa')
                table_width.set(qn('w:w'), str(int(CONTENT * 20)))
                cell_border = word_el('tblBorders')
                for side in ('top', 'left', 'bottom', 'right', 'insideH', 'insideV'):
                    cell_border.append(word_el(side, val='single', sz=4, color=BORDER))
                properties.append(cell_border)
                margin = word_el('tblCellMar')
                for side, points in (('top', 4), ('bottom', 4), ('left', 6), ('right', 6)):
                    margin.append(word_el(side, w=points * 20, type='dxa'))
                properties.append(margin)
                for column, width in zip(table.columns, widths):
                    column.width = Pt(width)
                for row_index, (row, values) in enumerate(zip(table.rows, rows)):
                    row_properties = row._tr.get_or_add_trPr()
                    row_properties.append(word_el('cantSplit'))
                    if row_index == 0:
                        row_properties.append(word_el('tblHeader'))
                    for width, cell, value in zip(widths, row.cells, values):
                        cell.width = Pt(width)
                        cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
                        if row_index == 0:
                            cell._tc.get_or_add_tcPr().append(word_el('shd', fill=SHADE))
                        paragraph = cell.paragraphs[0]
                        paragraph.style = 'Table Heading' if row_index == 0 else 'Table Text'
                        paragraph.add_run(value)
            else:
                style, value = block
                paragraph = doc.add_paragraph(value, style=style)
                if page_index and index == 0:
                    paragraph.paragraph_format.page_break_before = True
    doc.save(target)


def register_fonts():
    for name, filename in (('TNR', 'times.ttf'), ('TNR-Bold', 'timesbd.ttf')):
        pdfmetrics.registerFont(TTFont(name, f'C:/Windows/Fonts/{filename}'))


def make_pdf_paragraph(text, style_name):
    size, leading, _, _, bold, align = STYLES[style_name]
    font = 'TNR-Bold' if bold else 'TNR'
    style = ParagraphStyle(style_name, fontName=font, fontSize=size, leading=leading,
                           alignment=TA_CENTER if align == 'center' else TA_LEFT,
                           splitLongWords=True, allowWidows=1, allowOrphans=1)
    markup = escape(text).replace('\n', '<br/>')
    markup = re.sub(r'(https?://[^\s<]+)', r'<link href="\1">\1</link>', markup)
    if style_name == 'Report Code':
        markup = markup.replace(' ', '&nbsp;')
    return Paragraph(markup, style)


def pdf_from_docx(source, target):
    register_fonts()
    doc = Document(source)
    pdf = canvas.Canvas(str(target), pagesize=(WIDTH, HEIGHT), pageCompression=1)
    pdf.setTitle(TITLE)
    pdf.setSubject('Natural Language Processing Final Project')
    pdf.setAuthor('')
    cursor = HEIGHT - MARGIN
    page = 1
    space_after = 0

    def place(item, before=0):
        nonlocal cursor
        _, used = item.wrap(CONTENT, cursor - MARGIN)
        cursor -= max(before, space_after) + used
        if cursor < MARGIN + 10:
            raise ValueError(f'Page {page} exceeds text area at y={cursor:.1f}: {getattr(item, "text", "table")[:95]}')
        item.drawOn(pdf, MARGIN, cursor)

    def finish():
        if page > 1:
            pdf.setFont('TNR', 12)
            pdf.drawCentredString(WIDTH / 2, 35, str(page))
        print(f'Page {page}: {cursor:.0f} pt from bottom')
        pdf.showPage()

    for block in doc.iter_inner_content():
        if isinstance(block, WordTable):
            cell_rows = []
            for row_index, row in enumerate(block.rows):
                style_name = 'Table Heading' if row_index == 0 else 'Table Text'
                cell_rows.append([make_pdf_paragraph(cell.text, style_name) for cell in row.cells])
            widths = [column.width.pt for column in block.columns]
            table = Table(cell_rows, colWidths=widths, hAlign='LEFT')
            table.setStyle(TableStyle([
                ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
                ('GRID', (0, 0), (-1, -1), 0.5, colors.HexColor('#' + BORDER)),
                ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#' + SHADE)),
                ('TOPPADDING', (0, 0), (-1, -1), 4),
                ('BOTTOMPADDING', (0, 0), (-1, -1), 4),
            ]))
            place(table)
            space_after = 8
        else:
            if block.paragraph_format.page_break_before:
                finish()
                page += 1
                cursor, space_after = HEIGHT - MARGIN, 0
            _, _, before, after, _, _ = STYLES[block.style.name]
            place(make_pdf_paragraph(block.text, block.style.name), before)
            space_after = after

    finish()
    pdf.save()
