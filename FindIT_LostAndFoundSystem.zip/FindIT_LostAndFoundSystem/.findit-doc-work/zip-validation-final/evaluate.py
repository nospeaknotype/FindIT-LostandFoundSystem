"""Offline FindIT retrieval benchmark. Run: python evaluate.py --output results.json."""

import argparse
import csv
from datetime import date
import json
import math
from pathlib import Path
import re
import sys
import unicodedata

HERE = Path(__file__).resolve().parent
TEXT_FIELDS = ("name", "color", "description", "brand", "identifying_details")
SPLITS = ("dev", "test")
MINIMUM_SCORES = (40, 45, 50, 55, 60, 65, 70, 75)
EXAMPLES = (
    ("Q01", "name"), ("Q01", "description"), ("Q02", "name"),
    ("Q04", "description"), ("Q04", "location_other"), ("Q07", "color"),
    ("Q08", "name"), ("Q10", "description"), ("Q19", "description"),
    ("Q25", "description"), ("Q28", "description"), ("Q35", "name"),
)


def load_corpus(path):
    with path.open(encoding="utf-8-sig", newline="") as source:
        records = list(csv.DictReader(source))
    if len(records) < 50 or len({row["id"] for row in records}) != len(records):
        raise ValueError("The corpus must contain at least 50 records with unique IDs.")
    if len({(row["name"], row["description"]) for row in records}) != len(records):
        raise ValueError("Every record must have distinct item text.")
    by_id = {row["id"]: row for row in records}
    group_splits = {}
    for row in records:
        row["event_date"] = date.fromisoformat(row["event_date"])
        row["status"] = "open"
        if row["split"] not in SPLITS:
            raise ValueError("Unknown split.")
        if group_splits.setdefault(row["group"], row["split"]) != row["split"]:
            raise ValueError("A story group crossed partitions.")
        if row["expected"]:
            truth = by_id[row["expected"]]
            if truth["type"] != "found" or truth["group"] != row["group"]:
                raise ValueError("A relevant record must be in the query's group.")
    return records


def baseline_tokens(record):
    text = unicodedata.normalize("NFC", " ".join(record[field] for field in TEXT_FIELDS))
    return set(re.findall(r"[^\W_]+", text.lower()))


def baseline(query, candidates, contains):
    query_terms = baseline_tokens(query)
    ranked = []
    for candidate in candidates:
        terms = baseline_tokens(candidate)
        haystack = " " + " ".join(sorted(terms)) + " "
        shared = sum(contains(haystack, f" {term} ") for term in query_terms)
        if shared:
            ranked.append({"id": candidate["id"], "score": shared / len(query_terms | terms)})
    return sorted(ranked, key=lambda hit: (-hit["score"], hit["id"]))


def rerank(matcher, query_id, candidates, text_floor, min_score):
    results = [matcher.compare(query_id, candidate["id"]) for candidate in candidates]
    eligible = [
        result for result in results
        if result["signals"]["text"] >= text_floor and result["score"] >= min_score
    ]
    return sorted(eligible, key=lambda hit: (-hit["score"], -hit["signals"]["text"]))


def outcome(query, ranked):
    ids = [hit["id"] for hit in ranked]
    correct = bool(ids and ids[0] == query["expected"]) if query["expected"] else not ids
    return {
        "id": query["id"], "group": query["group"], "language": query["language"],
        "challenge": query["challenge"], "expected": query["expected"] or None,
        "correct": correct, "top": ranked[:3],
    }


def wilson(successes, total):
    if total == 0:
        return {"hits": successes, "total": total, "rate": None, "ci95": None}
    z = 1.959963984540054
    rate = successes / total
    denominator = 1 + z * z / total
    center = (rate + z * z / (2 * total)) / denominator
    half_width = z * math.sqrt((rate * (1 - rate) + z * z / (4 * total)) / total) / denominator
    return {
        "hits": successes, "total": total, "rate": rate,
        "ci95": [max(0, center - half_width), min(1, center + half_width)],
    }


def summarize(rows):
    matched = [row for row in rows if row["expected"]]
    unmatched = [row for row in rows if not row["expected"]]
    return {
        "matched_top1": wilson(sum(row["correct"] for row in matched), len(matched)),
        "matched_top3": wilson(
            sum(any(hit["id"] == row["expected"] for hit in row["top"]) for row in matched),
            len(matched),
        ),
        "no_match_rejection": wilson(sum(row["correct"] for row in unmatched), len(unmatched)),
        "all_correct": wilson(sum(row["correct"] for row in rows), len(rows)),
        "matched_top1_by_language": {
            language: wilson(
                sum(row["correct"] for row in matched if row["language"] == language),
                sum(row["language"] == language for row in matched),
            )
            for language in ("EN", "Mixed")
        },
    }


def score_partition(records, split, thresholds, Matcher, contains, min_text, min_score):
    partition = [row for row in records if row["split"] == split]
    candidates = [row for row in partition if row["type"] == "found"]
    queries = [row for row in partition if row["type"] == "lost"]
    scored = {
        "lexical": [],
        "hybrid_default": [],
        "hybrid_no_typos": [],
        **{threshold: [] for threshold in thresholds},
    }
    for query in queries:
        matcher_input = [*candidates, query]
        with_typos = Matcher(matcher_input)
        without_typos = Matcher(matcher_input, fix_typos=False)
        defaults = with_typos.matches(query["id"], limit=len(candidates))
        assert defaults == rerank(with_typos, query["id"], candidates, min_text, min_score)
        scored["lexical"].append(outcome(query, baseline(query, candidates, contains)))
        scored["hybrid_default"].append(outcome(query, defaults))
        scored["hybrid_no_typos"].append(
            outcome(query, without_typos.matches(query["id"], limit=len(candidates)))
        )
        for threshold in thresholds:
            ranked = rerank(with_typos, query["id"], candidates, min_text, threshold)
            scored[threshold].append(outcome(query, ranked))
    return scored


def evaluate(records, Matcher, contains, min_text, min_score):
    scored = {
        "dev": score_partition(
            records, "dev", MINIMUM_SCORES, Matcher, contains, min_text, min_score
        )
    }

    trial_results = {}
    for threshold in MINIMUM_SCORES:
        dev_summary = summarize(scored["dev"][threshold])
        top1 = dev_summary["matched_top1"]["rate"]
        no_match = dev_summary["no_match_rejection"]["rate"]
        trial_results[threshold] = (top1 + no_match) / 2
    threshold = max(
        MINIMUM_SCORES,
        key=lambda value: (trial_results[value], -abs(value - min_score), -value),
    )
    scored["test"] = score_partition(
        records, "test", (threshold,), Matcher, contains, min_text, min_score
    )
    variants = {}
    for split, prepared in scored.items():
        variants[split] = {}
        for name, key in (
            ("lexical", "lexical"), ("hybrid_default", "hybrid_default"),
            ("hybrid_no_typos", "hybrid_no_typos"), ("hybrid_tuned", threshold),
        ):
            variants[split][name] = {"metrics": summarize(prepared[key]), "cases": prepared[key]}
    return {
        "default_score_floor": min_score, "text_floor": min_text,
        "development_balanced_accuracy_by_threshold": trial_results,
        "selected_score_floor": threshold, "splits": variants,
    }


def preprocessing(records, clean, tokenize, analyze, stopwords, report_terms):
    by_id = {row["id"]: row for row in records}
    examples = []
    for record_id, field in EXAMPLES:
        raw = by_id[record_id][field]
        tokens = [token.word for token in tokenize(clean(raw))]
        normalized, entities = analyze(clean(raw))
        location_positions = {
            index for entity in entities if entity.label == "LOCATION"
            for index in range(entity.first, entity.last)
        }
        retained = [
            token.word for index, token in enumerate(normalized)
            if index not in location_positions and token.word not in stopwords and len(token.word) >= 2
        ]
        examples.append({
            "id": record_id, "field": field, "raw": raw,
            "tokens_after_folding_and_stemming": tokens,
            "retained_lexical_tokens": retained,
            "entities": [
                {
                    "value": entity.value, "label": entity.label, "text": entity.text,
                    "implies": entity.implies, "typos": entity.typos,
                }
                for entity in entities
            ],
            "weighted_text_features": dict(sorted(report_terms({field: raw}).items())),
        })
    return examples


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    default_repo = next((parent for parent in HERE.parents
                         if (parent / "backend" / "algorithms").is_dir()), None)
    parser.add_argument("--repo", type=Path, default=default_repo)
    parser.add_argument("--corpus", type=Path, default=HERE / "corpus.csv")
    parser.add_argument("--output", type=Path, default=HERE / "results.json")
    args = parser.parse_args()
    if args.repo is None or not (args.repo / "backend" / "algorithms").is_dir():
        parser.error("--repo must point to the FindIT workspace")
    sys.path.insert(0, str(args.repo.resolve() / "backend"))

    from algorithms.boyer_moore import contains
    from algorithms.ner import _analyze
    from algorithms.textutils import _clean, STOPWORDS, tokenize
    from algorithms.tfidf import Matcher, MIN_SCORE, MIN_TEXT, report_terms

    records = load_corpus(args.corpus)
    report = evaluate(records, Matcher, contains, MIN_TEXT, MIN_SCORE)
    report["preprocessing"] = preprocessing(records, _clean, tokenize, _analyze, STOPWORDS, report_terms)
    report["corpus_count"] = len(records)
    args.output.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
