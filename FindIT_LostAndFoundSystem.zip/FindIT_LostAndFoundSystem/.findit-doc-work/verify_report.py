from pathlib import Path
import re
import subprocess
import sys
from zipfile import ZipFile

from docx import Document
from pdfplumber import open as pdf_open
from pypdf import PdfReader
from PIL import Image, ImageDraw


WORK = Path(__file__).resolve().parent
OUT = WORK.parent / 'output' / 'FindIT NLP'
STEM = 'Campus Lost and Found System (FindIT)'
SOURCE = OUT / (STEM + '.docx')
PDF = OUT / (STEM + '.pdf')
ARCHIVE = OUT / 'FindIT NLP Evaluation Materials.zip'


def check_document():
    doc = Document(SOURCE)
    section = doc.sections[0]
    assert section.page_width.inches == 8.5 and section.page_height.inches == 11
    assert doc.styles['Normal'].font.name == 'Times New Roman'
    assert doc.styles['Normal'].font.size.pt == 12
    assert doc.styles['Heading 1'].font.size.pt == 14
    assert sum(paragraph.paragraph_format.page_break_before is True for paragraph in doc.paragraphs) == 13
    assert len(doc.tables[-1].rows) == 19
    assert doc.paragraphs[5].text == '\u00a0'
    assert all(doc.tables[index].rows[0]._tr.find('.//{*}tblHeader') is not None for index in range(len(doc.tables)))
    return doc


def check_pdf(doc):
    with pdf_open(PDF) as pdf:
        assert len(pdf.pages) == 14
        for number, page in enumerate(pdf.pages, 1):
            offenders = [char for char in page.chars if char['text'].strip()
                         and not (71 <= char['x0'] and char['x1'] <= 541
                                  and 71 <= char['top'] and char['bottom'] <= (768 if number > 1 else 721))]
            assert not offenders, (number, offenders[:5])
        pages = [page.extract_text() for page in pdf.pages]
    titles = [paragraph.text for paragraph in doc.paragraphs if paragraph.style.name == 'Heading 1']
    assert all(title in page for title, page in zip(titles, pages[1:], strict=True))
    assert '10/12' in pages[9] and '4/6' in pages[9] and '12/18' in pages[9]
    assert 'Q28' in pages[10] and 'F20 (96)' in pages[10]
    assert 'Samsng' in pages[12] and 'natitiklop' not in pages[12]
    reader = PdfReader(PDF)
    annotations = reader.pages[-1]['/Annots']
    assert sum('/URI' in item.get_object().get('/A', {}) for item in annotations) >= 4
    fonts = reader.pages[4]['/Resources']['/Font']
    embedded = [font.get_object() for font in fonts.values() if '/FontDescriptor' in font.get_object()]
    assert len(embedded) >= 2 and all('TimesNewRoman' in str(font['/BaseFont']) for font in embedded)


def check_archive(doc):
    extracted = WORK / 'zip-validation-final'
    with ZipFile(ARCHIVE) as archive:
        assert archive.testzip() is None
        archive.extractall(extracted)
    args = [sys.executable, '-B', 'evaluate.py', '--repo', '.', '--output', 'rerun.json']
    subprocess.run(args, check=True, cwd=extracted)
    assert (extracted / 'rerun.json').read_bytes() == (extracted / 'results.json').read_bytes()
    excerpt = next(paragraph.text for paragraph in doc.paragraphs
                   if paragraph.style.name == 'Report Code' and paragraph.text.startswith('from algorithms'))
    snippet = subprocess.run([sys.executable, '-B', '-c', excerpt], cwd=extracted / 'backend',
                             check=True, capture_output=True, text=True).stdout
    assert 'item:bottle' in snippet and 'color:blue' in snippet and 'boxes boxe box' in snippet
    print(snippet)


def render_contact_sheets():
    images = sorted(WORK.glob('page-*.png'))
    assert len(images) == 14, len(images)
    for offset in (0, 4, 8, 12):
        subset = images[offset:offset + 4]
        sheet = Image.new('RGB', (1508, 1984 if len(subset) == 4 else 992), '#dddddd')
        painter = ImageDraw.Draw(sheet)
        for index, image_path in enumerate(subset):
            page = Image.open(image_path).convert('RGB')
            page.thumbnail((726, 950))
            x, y = 20 + (index % 2) * 744, 30 + (index // 2) * 982
            sheet.paste(page, (x, y))
            painter.text((x, y - 16), f'Page {offset + index + 1}', fill='black')
        sheet.save(WORK / f'preview-{offset + 1:02d}.png')


if __name__ == '__main__':
    document = check_document()
    check_pdf(document)
    check_archive(document)
    render_contact_sheets()
    print('Verified Word properties, 14 PDF pages, embedded fonts and reproducible evaluation package.')
