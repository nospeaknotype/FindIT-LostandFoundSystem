
const STATUS = {
  pending: { label: "Pending", badge: "badge-warning" },
  matched: { label: "Match found", badge: "badge-info" },
  review: { label: "Under review", badge: "badge-info" },
  rejected: { label: "Not approved", badge: "badge-danger" },
  ready: { label: "Ready for claim", badge: "badge-success" },
  claimed: { label: "Claimed", badge: "badge-neutral" },
  // Found reports (the student turned something in)
  ownerFound: { label: "Owner found", badge: "badge-info" },
  returned: { label: "Returned", badge: "badge-neutral" },
};

const TYPE_LABELS = { lost: "Lost", found: "Found", claim: "Claim" };

const ICONS = {
  phone: '<rect x="5" y="2" width="14" height="20" rx="2"/><path d="M12 18h.01"/>',
  bottle: '<path d="M10 2h4"/><path d="M10.5 2v3L9 8v12a2 2 0 0 0 2 2h2a2 2 0 0 0 2-2V8l-1.5-3V2"/><path d="M9 12h6"/>',
  idCard: '<rect x="3" y="4" width="18" height="16" rx="2"/><circle cx="9" cy="10" r="2"/><path d="M15 8h2M15 12h2M7 16h10"/>',
  key: '<circle cx="7.5" cy="15.5" r="5.5"/><path d="m21 2-9.6 9.6M15.5 7.5l3 3L22 7l-3-3"/>',
  wallet: '<path d="M19 7V4a1 1 0 0 0-1-1H5a2 2 0 0 0 0 4h15a1 1 0 0 1 1 1v4h-3a2 2 0 0 0 0 4h3a1 1 0 0 0 1-1v-2a1 1 0 0 0-1-1"/><path d="M3 5v14a2 2 0 0 0 2 2h15a1 1 0 0 0 1-1v-4"/>',
  backpack: '<path d="M4 10a4 4 0 0 1 4-4h8a4 4 0 0 1 4 4v10a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2z"/><path d="M8 10h8M8 18h8"/><path d="M8 22v-6a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v6"/><path d="M9 6V4a2 2 0 0 1 2-2h2a2 2 0 0 1 2 2v2"/>',
  headphones: '<path d="M3 14h3a2 2 0 0 1 2 2v3a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-7a9 9 0 0 1 18 0v7a2 2 0 0 1-2 2h-1a2 2 0 0 1-2-2v-3a2 2 0 0 1 2-2h3"/>',
  umbrella: '<path d="M22 12a10 10 0 0 0-20 0Z"/><path d="M12 12v8a2 2 0 0 0 4 0"/><path d="M12 2v1"/>',
  shirt: '<path d="M20.4 3.5 16 2a4 4 0 0 1-8 0L3.6 3.5a2 2 0 0 0-1.3 2.2l.6 3.5a1 1 0 0 0 1 .8H6v10a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2V10h2.2a1 1 0 0 0 1-.8l.6-3.5a2 2 0 0 0-1.4-2.2z"/>',
  box: '<path d="M21 8 12 3 3 8v8l9 5 9-5z"/><path d="m3 8 9 5 9-5M12 13v8"/>',
  check: '<path d="M20 6 9 17l-5-5"/>',
};

// First match wins, so "earphone" is earbuds before it can be a phone.
const ICON_WORDS = [
  ["headphones", /earbud|earphone|headphone|headset/i],
  ["idCard", /\bid\b|license|card/i],
  ["key", /key/i],
  ["wallet", /wallet|purse/i],
  ["bottle", /bottle|tumbler|flask/i],
  ["phone", /phone/i],
  ["umbrella", /umbrella/i],
  ["backpack", /backpack|bag/i],
  ["shirt", /hoodie|jacket|shirt|uniform/i],
];
const CATEGORY_ICONS = { Electronics: "phone", Bags: "backpack", Clothing: "shirt", "ID & Docs": "idCard" };

// Tile color: blue while a match waits on the student, green once it's ready to pick up.
const STAGE_TONES = { matched: "blue", ready: "green" };

const FILTERS = [
  { key: "all", label: "All", test: () => true },
  { key: "lost", label: "Lost", test: (entry) => entry.type === "lost" },
  { key: "found", label: "Found", test: (entry) => entry.type === "found" },
  { key: "matches", label: "Matches", test: (entry) => stageOf(entry) === "matched" },
  { key: "claims", label: "Claims", test: (entry) => Boolean(entry.claim) },
];

const state = {
  entries: [],
  office: null,
  filter: "all",
  selectedId: null,
  selecting: false,
  selectedReports: new Set(),
  deleting: false,
};
let loadVersion = 0;

const els = {
  filters: document.getElementById("report-filters"),
  notice: document.getElementById("reports-notice"),
  layout: document.getElementById("reports-layout"),
  list: document.getElementById("report-list"),
  detail: document.getElementById("report-detail"),
  empty: document.getElementById("reports-empty"),
  selection: document.getElementById("report-selection"),
  selectionToggle: document.getElementById("report-selection-toggle"),
  selectionActions: document.getElementById("report-selection-actions"),
  selectionCount: document.getElementById("report-selection-count"),
  selectAll: document.getElementById("report-select-all"),
  clearSelection: document.getElementById("report-clear-selection"),
  deleteSelected: document.getElementById("report-delete-selected"),
};

const icon = (name, size = 22) =>
  `<svg width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${ICONS[name]}</svg>`;

const shortDate = (isoDate) =>
  new Date(`${isoDate}T00:00:00`).toLocaleDateString("en-US", { month: "short", day: "numeric" });
// Where a report or found item is, by name (../js/data/locations.js)
const where = (thing) => Locations.label(thing.locationId, thing.locationOther);
const stepTime = (iso) =>
  new Date(iso).toLocaleString("en-US", { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" });

const isNarrow = () => window.matchMedia("(max-width: 900px)").matches;
const selectedEntry = () => state.entries.find((entry) => entry.id === state.selectedId);
const visibleEntries = () => state.entries.filter(FILTERS.find((filter) => filter.key === state.filter).test);

// Where the report is from the student's side. A claim decision outranks the report's own status.
function stageOf(entry) {
  if (entry.type === "found") {
    return { matched: "ownerFound", ready: "ownerFound", claimed: "returned" }[entry.status] || "pending";
  }
  if (entry.status === "ready" || entry.status === "claimed") return entry.status;
  if (entry.claim?.status === "under_review") return "review";
  if (entry.claim?.status === "rejected") return "rejected";
  return entry.status; // pending | matched
}

function iconFor({ name, category }) {
  const found = ICON_WORDS.find(([, words]) => words.test(name));
  return found ? found[0] : CATEGORY_ICONS[category] || "box";
}

// `thing` is the report, or the found item in the match card; the color always follows the report.
const tile = (thing, entry, size) =>
  `<span class="item-tile tone-${STAGE_TONES[stageOf(entry)] || "gray"}">${icon(iconFor(thing), size)}</span>`;

const badgeHTML = (stage) => `<span class="badge ${STATUS[stage].badge}">${STATUS[stage].label}</span>`;

/* ---------- Progress ---------- */

// Steps up to `reached` are done; the last of those is the current one unless it's the final
// step. The step right after gets `next`, what it's waiting on.
function timeline(steps, reached, next) {
  const finished = reached === steps.length - 1;
  return steps.map(([label, time], index) => ({
    label,
    time: index <= reached ? time : null,
    state: index < reached || (index === reached && finished) ? "done" : index === reached ? "current" : "todo",
    note: index === reached + 1 ? next : "",
  }));
}

const CLAIM_NOTES = {
  review: "SWAFO is checking your claim",
  rejected: "Your claim wasn't approved",
  ready: "Pick it up at the SWAFO office",
};

function stepsFor(entry, stage) {
  if (entry.type === "found") {
    const reached = { ownerFound: 2, returned: 3 }[stage] ?? (entry.reviewedAt ? 1 : 0);
    return timeline([
      ["Report submitted", entry.submittedAt],
      ["SWAFO reviewing", entry.reviewedAt],
      ["Possible owner found", entry.matchedAt],
      ["Returned to owner", null],
    ], reached, ["Waiting", "Looking for the owner", "SWAFO is verifying the owner"][reached]);
  }

  if (entry.type === "claim") {
    return timeline([
      ["Claim submitted", entry.claim.submittedAt],
      ["Approved by SWAFO", entry.claim.reviewedAt],
      ["Picked up", null],
    ], { ready: 1, claimed: 2 }[stage] ?? 0, CLAIM_NOTES[stage]);
  }

  const reached = { matched: 2, review: 2, rejected: 2, ready: 3, claimed: 4 }[stage] ?? (entry.reviewedAt ? 1 : 0);
  const next = { matched: "Waiting for you to verify it's yours", ...CLAIM_NOTES }[stage]
    || (reached === 1 ? "Searching the found items" : "Waiting");
  return timeline([
    ["Report submitted", entry.submittedAt],
    ["SWAFO reviewing", entry.reviewedAt],
    ["Possible match found", entry.matchedAt],
    ["Ready for claim", entry.claim?.reviewedAt],
    ["Claimed", null],
  ], reached, next);
}

const STEP_STATES = { done: "Done", current: "Current step", todo: "Not yet" };

function timelineHTML(steps) {
  return `
    <ol class="timeline">
      ${steps.map((step) => `
        <li class="is-${step.state}"${step.state === "current" ? ' aria-current="step"' : ""}>
          <span class="step-dot" aria-hidden="true">${step.state === "done" ? icon("check", 13) : ""}</span>
          <div>
            <span class="step-label"><span class="visually-hidden">${STEP_STATES[step.state]}: </span>${escapeText(step.label)}</span>
            ${step.time ? `<span class="step-sub"><time datetime="${escapeText(step.time)}">${stepTime(step.time)}</time></span>` : ""}
            ${step.note ? `<span class="step-sub">${escapeText(step.note)}</span>` : ""}
          </div>
        </li>`).join("")}
    </ol>`;
}

/* ---------- The found item and what to do next ---------- */

function matchCardHTML(entry) {
  const { item, match } = entry;
  const score = match ? Number(match.score) : null;
  return `
    <div class="match-card">
      <div class="match-row">
        ${tile(item, entry, 20)}
        <div>
          <a class="match-name" href="item-details.html?id=${encodeURIComponent(item.id)}">${escapeText(item.name)}</a>
          <span class="match-sub">Found at ${escapeText(where(item))} &middot; ${shortDate(item.dateFound)}</span>
        </div>
        ${score === null ? "" : `<span class="match-score"><span class="visually-hidden">Match score: </span>${score}%</span>`}
      </div>
      ${score === null ? "" : `<span class="match-bar" aria-hidden="true"><span style="width: ${score}%"></span></span>`}
    </div>`;
}

const messageLink = (itemId) =>
  `<a class="btn btn-outline btn-block" href="messages.html?item=${encodeURIComponent(itemId)}">Message SWAFO</a>`;

function nextStepHTML(entry, stage) {
  const { item, claim } = entry;

  if (stage === "matched") {
    // Someone else's claim was approved first, so this student can't claim it from here.
    const claimable = item.status === "pending" || item.status === "matched";
    return `
      <div class="detail-actions">
        ${claimable
          ? `<a class="btn btn-primary btn-block" href="claim.html?id=${encodeURIComponent(item.id)}">Verify and claim</a>`
          : '<button type="button" class="btn btn-primary btn-block" disabled>Verify and claim</button>'}
        <button type="button" class="btn btn-outline btn-block" data-action="not-mine">Not mine</button>
      </div>
      ${claimable ? "" : `<p class="detail-note">SWAFO has already approved a claim for this item. If it's yours, <a href="messages.html?item=${encodeURIComponent(item.id)}">message SWAFO</a>.</p>`}`;
  }

  const { office } = state;
  const text = {
    review: `You sent a claim on ${stepTime(claim.submittedAt)}. SWAFO is checking your answers and will message you once it's decided.`,
    rejected: "SWAFO couldn't verify that this item is yours. If you have more proof, send them a message.",
    ready: `Your claim was approved. Pick it up at the ${escapeText(office.name)}, ${escapeText(office.location)} (${escapeText(office.pickupHours)}). Bring your school ID and claim no. ${escapeText(claim.id)}.`,
    claimed: "You picked this item up. Glad it found its way back to you!",
  }[stage];
  return `
    <p class="detail-box${stage === "ready" ? " is-success" : ""}">${text}</p>
    ${stage === "claimed" ? "" : `<div class="detail-actions">${messageLink(item.id)}</div>`}`;
}

function foundSideHTML(entry, stage) {
  const text = {
    pending: "Thanks for turning it in. SWAFO is looking for the owner, and you don't need to do anything else.",
    ownerFound: "Someone reported losing an item like this. SWAFO will check that they're the owner before handing it over.",
    returned: "SWAFO returned this item to its owner. Thank you for turning it in!",
  }[stage];
  return `
    <h3 class="detail-label">What happens next</h3>
    <p class="detail-box">${text}</p>
    ${stage === "returned" ? "" : `<div class="detail-actions">${messageLink(entry.id)}</div>`}`;
}

function noMatchHTML(entry) {
  return `
    <h3 class="detail-label">Possible match</h3>
    <div class="match-card match-empty">
      <p><strong>No match yet</strong></p>
      <p>SWAFO compares new found items with your report. A match will show up here.</p>
    </div>
    <div class="detail-actions">
      <a class="btn btn-outline btn-block" href="items.html">Browse found items</a>
      ${entry.canDelete ? '<button type="button" class="btn-link btn-cancel" data-action="cancel">Cancel this report</button>' : ""}
    </div>`;
}

function sideHTML(entry, stage) {
  if (entry.type === "found") return foundSideHTML(entry, stage);
  if (!entry.item) return entry.type === "lost" ? noMatchHTML(entry) : "";

  const heading = entry.type === "claim"
    ? "Item you claimed"
    : stage === "ready" || stage === "claimed" ? "Your item" : "Possible match";
  return `
    <h3 class="detail-label">${heading}</h3>
    ${matchCardHTML(entry)}
    ${nextStepHTML(entry, stage)}
    ${entry.type === "lost" ? '<p class="detail-note">You can cancel a report only while it is still pending.</p>' : ""}`;
}

function detailMeta(entry) {
  const what = entry.type === "claim" ? `Claimed ${shortDate(entry.date)}` : `${TYPE_LABELS[entry.type]} at ${where(entry)}`;
  return `${escapeText(entry.id)} &middot; ${escapeText(what)}`;
}

/* ---------- Rendering ---------- */

function renderFilters() {
  els.filters.innerHTML = FILTERS.map(({ key, label, test }) => `
    <button type="button" class="report-filter" data-filter="${key}" aria-pressed="${key === state.filter}">
      ${label} &middot; ${state.entries.filter(test).length}
    </button>`).join("");
}

function renderSelectionControls(visible = visibleEntries()) {
  const { selecting, selectedReports, deleting } = state;
  const eligible = visible.filter((entry) => entry.canDelete);
  const selectedInView = eligible.filter((entry) => selectedReports.has(entry.id)).length;
  const outside = selectedReports.size - selectedInView;
  const countText = `${selectedReports.size} selected${outside ? ` (${outside} outside this filter)` : ""}. Only pending reports without claims can be deleted.`;
  els.selection.hidden = !state.entries.some((entry) => entry.type !== "claim");
  els.selectionToggle.setAttribute("aria-expanded", String(selecting));
  els.selectionToggle.textContent = selecting ? "Done selecting" : "Select reports";
  els.selectionToggle.disabled = deleting;
  els.selectionActions.hidden = !selecting;
  if (els.selectionCount.textContent !== countText) els.selectionCount.textContent = countText;
  els.selectAll.disabled = deleting || !eligible.length;
  els.clearSelection.disabled = deleting || !selectedReports.size;
  els.deleteSelected.disabled = deleting || !selectedReports.size;
  els.list.querySelectorAll("[data-report-select]").forEach((box) => {
    box.checked = selectedReports.has(box.dataset.reportSelect);
    box.disabled = deleting;
  });
  const cancel = els.detail.querySelector('[data-action="cancel"]');
  if (cancel) cancel.disabled = deleting;
}

function renderList(entries) {
  els.list.classList.toggle("is-selecting", state.selecting);
  if (!entries.length) {
    els.list.innerHTML = '<li class="report-list-empty">Nothing here right now.</li>';
    return;
  }
  els.list.innerHTML = entries.map((entry) => {
    const meta = [TYPE_LABELS[entry.type], where(entry), shortDate(entry.date), entry.id].map(escapeText).join(" &middot; ");
    return `
      <li class="report-select-row">
        ${state.selecting && entry.canDelete ? `<input type="checkbox" class="report-select-checkbox" data-report-select="${escapeText(entry.id)}" aria-label="Select ${escapeText(entry.name)}, ${escapeText(entry.id)}">` : ""}
        <button type="button" class="report-card" data-id="${escapeText(entry.id)}"${entry.id === state.selectedId ? ' aria-current="true"' : ""}>
          ${tile(entry, entry)}
          <span>
            <span class="report-card-title">${escapeText(entry.name)}</span>
            <span class="report-card-meta">${meta}</span>
          </span>
          ${badgeHTML(stageOf(entry))}
        </button>
      </li>`;
  }).join("");
}

function renderDetail() {
  const entry = selectedEntry();
  els.detail.hidden = !entry;
  if (!entry) {
    els.detail.replaceChildren();
    return;
  }
  const stage = stageOf(entry);
  els.detail.innerHTML = `
    <header class="detail-head">
      ${tile(entry, entry, 28)}
      <div>
        <h2 id="detail-title" tabindex="-1">${escapeText(entry.name)}</h2>
        <p class="detail-meta">${detailMeta(entry)}</p>
      </div>
      ${badgeHTML(stage)}
    </header>
    <div class="detail-body">
      <div>
        <h3 class="detail-label">Progress</h3>
        ${timelineHTML(stepsFor(entry, stage))}
      </div>
      <div class="detail-side">${sideHTML(entry, stage)}</div>
    </div>`;
}

// The list and details for the current filter. Keeps the selection if it's still listed.
function renderView() {
  const visible = visibleEntries();
  if (!visible.some((entry) => entry.id === state.selectedId)) state.selectedId = visible[0]?.id ?? null;
  renderList(visible);
  renderDetail();
  renderSelectionControls(visible);
}

function render() {
  const hasEntries = state.entries.length > 0;
  els.empty.hidden = hasEntries;
  els.filters.hidden = !hasEntries;
  els.layout.hidden = !hasEntries;
  if (!hasEntries) {
    state.selecting = false;
    renderView();
    return;
  }
  renderFilters();
  renderView();
}

const focusDetail = () => document.getElementById("detail-title")?.focus({ preventScroll: true });

function setNotice(message, error = false) {
  els.notice.classList.toggle("is-error", error);
  els.notice.textContent = message;
}

// Fetches again after a change. Re-rendering replaces the buttons, so focus goes back to the
// same filter or report if it was on one.
async function load({ initial = false } = {}) {
  const version = ++loadVersion;
  const entries = await UserAPI.getMyReports();
  if (version !== loadVersion) return;
  const focusAttributes = ["data-id", "data-filter", "data-report-select", "data-action"];
  const focused = document.activeElement?.closest(focusAttributes.map((name) => `[${name}]`).join(", "));
  const attribute = focused && focusAttributes.find((name) => focused.hasAttribute(name));
  const eligible = new Set(entries.filter((entry) => entry.canDelete).map((entry) => entry.id));
  const previousCount = state.selectedReports.size;
  state.selectedReports = new Set([...state.selectedReports].filter((id) => eligible.has(id)));
  state.entries = entries;
  if (initial) state.selectedId = initialSelection();
  render();
  if (state.selectedReports.size !== previousCount && !state.deleting) {
    setNotice("Some selected reports changed. Review the current selection before deleting.", true);
  }
  if (attribute) {
    const restored = document.querySelector(`[${attribute}="${CSS.escape(focused.getAttribute(attribute))}"]`);
    const fallback = els.layout.hidden ? document.getElementById("reports-empty-title") : els.list.querySelector(".report-card");
    (restored || fallback)?.focus();
  }
}

function focusAfterDeletion() {
  if (state.selecting && !els.selectAll.disabled) els.selectAll.focus();
  else if (selectedEntry()) focusDetail();
  else if (!els.selection.hidden) els.selectionToggle.focus();
  else if (!els.empty.hidden) document.getElementById("reports-empty-title").focus();
}

async function deleteEntries(references, request, successMessage) {
  state.deleting = true;
  loadVersion++; // Ignore a poll that started before the deletion.
  setNotice("");
  renderSelectionControls();
  let moveFocus = false;
  try {
    const result = await request();
    if (result?.success !== true) throw new Error("server");
    const deleted = new Set(references);
    state.entries = state.entries.filter((entry) => !deleted.has(entry.id));
    references.forEach((id) => state.selectedReports.delete(id));
    render();
    setNotice(successMessage);
    moveFocus = true;
    await load().catch(() => {}); // The server already confirmed the deletion.
  } catch (error) {
    if (error.message === "not_pending" || error.message === "not_found") {
      try {
        await load();
        setNotice("Some reports changed. Only pending reports without claims can be deleted. Review the selection and try again.", true);
      } catch {
        setNotice("Some reports changed. Refresh this page before trying to delete again.", true);
      }
      moveFocus = true;
    } else {
      const messages = {
        invalid_selection: "Choose at least one pending report without claims.",
        login_required: "Please log in again before deleting any reports.",
        database_error: "The server couldn't save the deletion. Try again.",
      };
      setNotice(messages[error.message] || "Couldn't confirm the deletion. Check your connection and try again.", true);
    }
  } finally {
    state.deleting = false;
    renderSelectionControls();
    if (moveFocus) focusAfterDeletion();
  }
}

/* ---------- Events ---------- */

els.filters.addEventListener("click", (event) => {
  const button = event.target.closest("[data-filter]");
  if (!button) return;
  state.filter = button.dataset.filter;
  els.filters.querySelectorAll("[data-filter]").forEach((b) => b.setAttribute("aria-pressed", String(b === button)));
  renderView();
});

els.selectionToggle.addEventListener("click", () => {
  state.selecting = !state.selecting;
  if (!state.selecting) state.selectedReports.clear();
  renderView();
});

els.selectAll.addEventListener("click", () => {
  visibleEntries().filter((entry) => entry.canDelete).forEach((entry) => state.selectedReports.add(entry.id));
  renderSelectionControls();
});

els.clearSelection.addEventListener("click", () => {
  state.selectedReports.clear();
  renderSelectionControls();
  (els.selectAll.disabled ? els.selectionToggle : els.selectAll).focus();
});

els.deleteSelected.addEventListener("click", () => {
  const references = [...state.selectedReports];
  if (state.deleting || !references.length) return;
  const reports = `${references.length} ${references.length === 1 ? "report" : "reports"}`;
  if (!window.confirm(`Permanently delete ${reports}? This cannot be undone.`)) return;
  deleteEntries(references, () => UserAPI.deleteReports(references), `Deleted ${reports}.`);
});

els.list.addEventListener("change", (event) => {
  const box = event.target.closest("[data-report-select]");
  if (!box || state.deleting) return;
  const id = box.dataset.reportSelect;
  if (box.checked) state.selectedReports.add(id);
  else state.selectedReports.delete(id);
  renderSelectionControls();
});

els.list.addEventListener("click", (event) => {
  const card = event.target.closest(".report-card");
  if (!card) return;
  state.selectedId = card.dataset.id;
  els.list.querySelectorAll(".report-card").forEach((c) => {
    if (c === card) c.setAttribute("aria-current", "true");
    else c.removeAttribute("aria-current");
  });
  setNotice("");
  renderDetail();
  renderSelectionControls();
  // On a phone the details are above the list, so take the student back up to them.
  if (isNarrow()) {
    els.detail.scrollIntoView({ behavior: "smooth", block: "start" });
    focusDetail();
  }
});

els.detail.addEventListener("click", (event) => {
  const action = event.target.closest("[data-action]")?.dataset.action;
  const entry = selectedEntry();
  if (!action || !entry) return;
  const name = entry.name.toLowerCase();

  if (action === "not-mine") {
    if (!window.confirm(`Is the ${entry.item.name} not yours? SWAFO will keep looking for your ${name}.`)) return;
    UserAPI.rejectMatch(entry.id).then(load).then(() => {
      els.notice.textContent = `Thanks for letting us know. Your ${name} report is back to Pending, and SWAFO will keep looking.`;
      focusDetail();
    });
  }

  if (action === "cancel") {
    if (state.deleting || !entry.canDelete) return;
    if (!window.confirm(`Cancel your report for the ${name}? SWAFO will stop looking for it.`)) return;
    deleteEntries([entry.id], () => UserAPI.cancelReport(entry.id), `Your ${name} report was cancelled.`);
  }
});

/* ---------- Start ---------- */

// my-reports.html?id= can name the report, the student's claim, or the found item.
function initialSelection() {
  const id = new URLSearchParams(window.location.search).get("id");
  const linked = id && state.entries.find((entry) => entry.id === id || entry.claim?.id === id || entry.item?.id === id);
  return (linked || state.entries.find((entry) => stageOf(entry) === "matched") || state.entries[0])?.id ?? null;
}

UserAPI.getOffice().then((office) => {
  state.office = office;
  return load({ initial: true });
}).catch(() => {
  setNotice("Couldn't load your reports. Check that FindIt is running and refresh the page.", true);
});

UserAPI.onReportsChange(() => {
  if (!state.deleting) load().catch(() => {});
});
