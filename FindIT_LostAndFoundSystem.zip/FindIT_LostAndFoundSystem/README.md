# FindIt

## Run on Windows

Install a current [Python 3 release](https://www.python.org/downloads/) with the `py` launcher. Python 3.13 is recommended. Extract the entire project into a writable folder, such as a folder inside Documents. Open the extracted folder in VS Code, then run these commands from its terminal.

```powershell
cd backend
py app.py
```

If the selected Python needs Flask or the other dependencies, FindIt installs them from `requirements.txt` into `backend/.venv`. That first-time setup needs an internet connection. Later launches can reuse the environment offline.

If Windows does not recognize `py`, you can use `python app.py` when Python is on your PATH.

Open the URL printed after `Running on`. The usual address is [http://127.0.0.1:5000](http://127.0.0.1:5000/). If port 5000 is busy, FindIt picks a free port. To choose one yourself, run `py app.py --port 5001`. Keep the terminal open while using FindIt. Press **Ctrl+C** to stop the server.

FindIt checks that it can write to `instance` for reports and `static/uploads` for photos. If startup reports a write error, check the path shown in the terminal, make sure the project folder is writable, and check that the drive has free space.

On macOS or Linux, run `python3 app.py` from `backend` with Python's `venv` and `pip` support installed.

## Move the project to another computer

Keep `backend`, `templates`, and `static` together. To move existing records and images, stop FindIt first, then copy the `instance` folder and keep the `static/uploads` folder inside the copy of `static`. For a fresh database, omit `instance` and `static/uploads` when making the copy. FindIt creates both directories as needed. Leave `backend/.venv` out of either copy so each computer can set up its own environment.
